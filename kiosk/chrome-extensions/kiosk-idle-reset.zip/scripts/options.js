// Save options to chrome.storage.
const saveOptions = () => {
    const reset_url = document.getElementById("option_reset_url").value;
    const idle_timeout = document.getElementById("option_idle_timeout").value || 60;
    if (reset_url == "" || idle_timeout < 15) {
        const status = document.getElementById("status");
        status.textContent = "Could not save the options. Please review the highlighted option(s) and try again.";
    } else {
        chrome.storage.local.set(
            { resetURL: reset_url, idleTimeout: idle_timeout },
            () => {
                // Update status to let user know options were saved.
                const status = document.getElementById("status");
                status.textContent = "Options saved.";
                setTimeout(() => {
                    status.textContent = "";
                }, 750);
            }
        );
    }
};

// Restore the options state, using the preferences stored in chrome.storage.
const restoreOptions = () => {
    chrome.storage.local.get(
        { resetURL: "", idleTimeout: 60 },
        (items) => {
            document.getElementById("option_reset_url").value = items.resetURL;
            document.getElementById("option_idle_timeout").value = items.idleTimeout;
        }
    );
};

document.addEventListener("DOMContentLoaded", restoreOptions);
document.getElementById("save").addEventListener("click", saveOptions);