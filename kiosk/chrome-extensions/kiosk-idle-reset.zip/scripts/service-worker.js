(async () => {

    // Retrieve options from storage.local
    const options = {resetURL: "", idleTimeout: 60 };
    const storage = await chrome.storage.local.get(options).then((items) => {
        Object.assign(options, items);
    });

    // Set the idle interval
    chrome.idle.setDetectionInterval(Number(options.idleTimeout));

    // Implement hard reset
    chrome.idle.onStateChanged.addListener((newstate) => {
        if (newstate == "idle") {
            console.log("idle timeout");
            if (options.resetURL != "") {
                console.log("reset initiated");
                chrome.tabs.create({
                    url: options.resetURL,
                    active: true
                }, (newtab) => {        
                    chrome.tabs.query({}, (results) => {
                        for (var i = 0; i < results.length; i++) {
                            var tab = results[i];        
                            if (tab.id != newtab.id) {
                                chrome.tabs.remove(tab.id);
                            }        
                        }
                    });
                });
            }
        }
    });

})();