(async () => {
    
    // Retrieve options from storage.local
    const options = {};
    const storage = await chrome.storage.local.get().then((items) => {
        Object.assign(options, items);
    });

    // Create the content
    const content = document.createElement("div");
    content.classList.add("chrome-extension-kiosk-buttons");

    // Create a container for the buttons
    const button_group = document.createElement("div");
    button_group.classList.add("btn-group");
    content.append(button_group);

    // Create the back button
    if (options.backButtonEnabled) {
        const back_button = document.createElement("button");
        back_button.textContent = "Back";
        back_button.addEventListener("click", (event) => {
            if (document.referrer !="" && (options.backButtonEnabled && (document.referrer != window.location.href)))
                history.back();
        });
        back_button.setAttribute("id", "back");
        button_group.append(back_button);
    }

    // Create the reset button
    const reset_button = document.createElement("button");
    reset_button.textContent = "Reset";
    reset_button.addEventListener("click", (event) => {
        if (options.resetURL != "" && (window.location.href != options.resetURL))
            window.location.href = options.resetURL;
    });
    reset_button.setAttribute("id", "reset");
    button_group.append(reset_button);

    // Inject the buttons
    const parent = document.querySelector("body");
    parent.prepend(content);

})();
