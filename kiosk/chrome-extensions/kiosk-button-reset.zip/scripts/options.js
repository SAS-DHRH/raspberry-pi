// Save options to chrome.storage.
const saveOptions = () => {
    const reset_url = document.getElementById("option_reset_url").value;
    const back_enabled = document.getElementById("option_back_enabled").checked;
    if (reset_url == "") {
        const status = document.getElementById("status");
        status.textContent = "Could not save the options. Please review the highlighted option(s) and try again.";
    } else {
        chrome.storage.local.set(
            { resetURL: reset_url, backButtonEnabled: back_enabled },
            () => {
                // Update status to let user know options were saved.
                const status = document.getElementById("status");
                status.textContent = "Options saved.";
                setTimeout(() => {
                    status.textContent = "";
                }, 750);
            }
        );
    }
};

// Restore the options state, using the preferences stored in chrome.storage.
const restoreOptions = () => {
    chrome.storage.local.get(
        { resetURL: "", backButtonEnabled: false },
        (items) => {
            document.getElementById("option_reset_url").value = items.resetURL;
            document.getElementById("option_back_enabled").checked = items.backButtonEnabled;
        }
    );
};

document.addEventListener("DOMContentLoaded", restoreOptions);
document.getElementById("save").addEventListener("click", saveOptions);